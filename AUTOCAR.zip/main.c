/*
 * 01.LED_CONTROL.c
 *
 * Created: 2025-03-04 오후 4:25:34
 * Author : microsoft
 */ 

#include "button.h"
#include <avr/interrupt.h>  // sei()등 
#include <stdio.h>  // printf scanf fgets puts gets 등이 들어 있다. 
#include "extern.h"
#include "def.h"

void manual_mode(void);
void distance_check(void);
void auto_mode(void); 

volatile int msec_count = 0;
volatile int ultrasonic_check_timer = 0;

// for printf 
FILE OUTPUT = FDEV_SETUP_STREAM(UART0_transmit, NULL, _FDEV_SETUP_WRITE);

int func_index = MANUAL_MODE;

void (*pfunc[]) () = 
{
	manual_mode,        // 수동모드
	distance_check,     // 초음파 거리 측정
	auto_mode_check,    // button check
	auto_mode           // 자율 주행
};

ISR(TIMER0_OVF_vect)
{
	// 6~256 : 250(1ms) 그래서 TCNT0를 6으로 설정하는것이다. 
	TCNT0 = 6;
	msec_count++;   // 1ms마다 1씩 증가
	ultrasonic_check_timer++;
}

int main(void)
{
	init_timer0();
	init_timer1();
	init_L298N();
	init_uart0();
	init_uart1();
	//init_ultrasonic();`
	init_button();
	init_led();
	stdout = &OUTPUT;   // printf가 동작 될 수 있도록 stdout에 OUTPUT 화일 포인터 assign 
	sei();   // 전역(대문)으로 interrupt 허용'
	
	while(1)
	{
		pfunc[func_index]();
	}
}

// timer0를 초기화 시키는 부분
// AVR에서 8bit timer 0/2번중 0번을 초기화 한다.
// 임베디드/FPGA 등에서 제일 중요한것은 초기화를 정확히 해주는것이다. 
// 그래서 이부분을 특별히 신경을 써서 작성 한다. 

void init_timer0(void)
{
	// 16MHZ /64 분주(down) 분주: divider/prescale
	// ------ 분주비 계산 ----
	// (1) 16000000Hz/64 ==> 250,000HZ
	// (2) T(주기) 1clock의 소요시간 : 1/f = 1/250,000 ==> 0.0000004sec(4us) : 0.004ms	
	// (3) 8bit timer OV(OVflow) : 0.004ms x 256 = 0.001024sec --> 1.024ms 
	// 1ms마다 정확하게 INT를 띄우고 싶은면 0.004ms x 250개를 count = 0.001sec ==>1ms
	TCNT0 = 6;   // TCNT : 0~256 1ms 마다 TIMER0_OVF_vect로 진입 한다. 
	           // TCNT0 = 6으로 설정을 한 이유: 6-->256 : 250개의 펄스를 count하기 때문에 정확히 1ms가 된다.
	// (4) 분주비 설정 64분주 (250,000HZ --> 250KHz) P296 표13-1
	TCCR0 |= 1 << CS02 | 0 << CS01 | 0 << CS00;  // TCCR0 |= 0xf4 보다는 죄측의 code 권장 
	// (5) Timer0 overflow INT를 허용(enable)
	TIMSK |= 1 << TOIE0;  // TIMSK |= 0x01; 
}


void manual_mode(void)        // 수동모드
{
	switch(bt_data)
	{
		case 'F' :
		case 'f' :
			forward(500); //4us x 500 = 0.002sec (2ms)
			break;
		case 'B' :
		case 'b' :
			backward(500); //4us x 500 = 0.002sec (2ms)
			break;
		case 'L' :
		case 'l' :
			turn_left(700);
			break;
		case 'R' :
		case 'r' :
			turn_right(700);
			break;
		case 'S' :
		case 's' :
			stop();
			break;
		default:
			break;	
	}
	 func_index = DISTANCE_CHECK;  
}

void distance_check(void)     // 초음파 거리 측정
{
	func_index = MODE_CHECK;
}

void auto_mode(void)          // 자율 주행
{
	func_index = MANUAL_MODE;
}