﻿/*
 * def.h
 *
 * Created: 2025-03-10 오후 3:05:47
 *  Author: microsoft
 */ 


#ifndef DEF_H_
#define DEF_H_

#define  COMMAND_NUMBER 10
#define  COMMAND_LENGHT 40



#endif /* DEF_H_ */